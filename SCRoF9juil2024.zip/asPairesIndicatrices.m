function AS=asPairesIndicatrices(AS)
% AS=asPairesIndicatrices(AS);
% Identifier les variables indicatrices, s'il y en a pour la branche AS.branche
br=AS.branche;
AS.P(br).Cpaires=nchoosek(AS.P(br).pertinent,2); % tous les sous-ensembes de 2 parmi les v
nc=size(AS.P(br).Cpaires,1);
AS.P(br).Crit=zeros(nc,1);
AS.P(br).Corr=zeros(AS.nv,nc);
AS.P(br).Ppaires=zeros(nc,1);
for k=1:nc
    % AS=asTuples(AS,k);
    AS=asAnnulePaire(AS,k);  % optimiser les variables de la rangée k de AS.Cpaires
end
% AS.P(br).Crit=AS.P(br).Crit*(AS.N-1);
AS.P(br).z2=(AS.P(br).Corr).^2*(AS.N-1);