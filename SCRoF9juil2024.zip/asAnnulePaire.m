function AS=asAnnulePaire(AS,k)
% AS=asAnnulePaire(AS,k);
% AS.GS(v,v) est la GrammSchmidt (en triangle supérieur) de R(v,v)
% k est un scalaire
% Optimise les variables de la rangée k de AS.P(br).Cpaire pour en
% minimiser le signal si les poids r et 1/r de la paire de variables
% donnent la plus grande corrélation absolue de signes opposés
% autrementm celui de r et 1/r qui donne la plus grande corrélation absolue
% est gardé comme poids, pour que le critère ne permette pas de regrouper
% ces variables
% remplit AS.P(br).Crit(k), AS.P(br).Ppaires(k) et AS.P(br).Corr(:,k)
% AS.P(br).Crit(k) est déjà le X2: N-1 fois la somme des corrélations au carré
br=AS.branche;
G=AS.GS;
% if ~isfield(AS.P(br),'pertinent')
%     AS.P(br).pertinent=1:AS.nv;
% end
cible=AS.P(br).pertinent;
melange=AS.P(br).Cpaires(k,:);
r=AS.R(melange(1),melange(2));
[crit1,corr1]=asCrit(r,G,melange,cible);
[crit2,corr2]=asCrit(1/r,G,melange,cible);
f=find(corr1.^2==crit1,1);
if corr1(f)*corr2(f)>0    % si pas d'inversion de signe de corrélation entre r et 1/r
    if crit1>crit2
        corr=corr1;
        P=r;
    else
        corr=corr2;
        P=1/r;
    end
else
    options=optimset('MaxFunEvals',1e4,'MaxIter',1e4,'TolFun',1e-4,'TolX',1e-4);
    P=(r+1/r)/2;
    P=fminsearch(@(P) asCrit(P,G,melange,cible),P,options);
    if P<r || P>1/r
        keyboard
    end
    [~,corr]=asCrit(P,G,melange,cible);
end
AS.P(br).Crit(k)=corr*corr'*(AS.N-1);
AS.P(br).Corr(:,k)=corr;
AS.P(br).Ppaires(k)=P;
