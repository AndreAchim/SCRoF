function AS=asDistances(AS)
% AS=asDdistances(AS);
br=AS.branche;
np=numel(AS.P(br).pertinent);
Dist=zeros(np);
for k=1:numel(AS.P(br).Crit)
    Dist(AS.P(br).Cpaires(k,1),AS.P(br).Cpaires(k,2))=AS.P(br).Crit(k);
end 
AS.P(br).Dist=triU(Dist)';