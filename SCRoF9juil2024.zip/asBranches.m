function AS=asBranches(AS)
% AS=asBranches(AS);
% Explore la structure d'arbre et ajoute dans AS le champ .scenario
% contenant les divers scénarios produits, par ordre décroissant de
% probabilités associées au X2 d'ajustement
branches=[];
br=zeros(1,3);
for p=1:numel(AS.P)
    br(1)=p;
    for g=1:numel(AS.P(p).G)
        br(2)=g;
        for c=1:numel(AS.P(p).G(g).C)
            br(3)=c;
            branches=[branches;[AS.P(p).G(g).C(c).Fit br]];
        end
    end
end
[~,o]=sort(branches(:,1),'descend');
AS.scenario=branches(o,:);