function AS=SCRoF(R,N,varargin)
% AS=SCRoF(R,N,seuils);    ou AS=SCFA(dat,seuils);
% R peut être une matrice de covariances
% AS est une structure avec divers champs dont
% .R, .N, .GS, .Fct, .CorFct, .Gr, .Ppaires, .Cpaires
% seuils(2) (défaut [.01 .2]) donne les limites d'ambiguité amenant les
% décisions sattistiques à un branchement des deux possibilités de décision
AS.seuils=[.01 .2];
AS.dat=R;
[n,nv]=size(R);
if n>nv  % matrice de données en entrée
    if nargin>1
        AS.seuils=N;
    end
    N=n;
    R=cov(R);
else
    if nargin>2
        AS.seuils=varargin{1};
    end
end
AS.seuils=sort(AS.seuils);
if numel(AS.seuils)==1
    AS.seuils=[AS.seuils,AS.seuils];
end
AS.Lseuils=-log10(AS.seuils);
AS.et=sqrt(diag(R));  % ceci est destiné à pouvoir exprimer la solution factorielle en termes des variables d'origine
iet=1./AS.et;
AS.R=R.*(iet*iet');
AS.N=N;
AS.nv=numel(iet);
GS=chol(AS.R);
AS=asOrphelines(AS);
for br=1:numel(AS.P)
    AS.branche=br;
    AS.GS=GS;
    if ~isempty(AS.P(br).orphelines)
        f=AS.P(br).orphelines;
        AS.GS(:,f)=0; % pour rendre toutes les corrélations (sommes d eproduits) nulles sans mélanger les rangs des variables
    end
    AS.P(br).pertinent=setdiff(1:AS.nv,AS.P(br).orphelines);
    AS=asPairesIndicatrices(AS);
    AS=asGrappes(AS);  % défini aussi AS.reste
end
AS=asBranches(AS);