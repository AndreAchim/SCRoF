function [p,X2,df]=asFit(AS)
% X2=asFit(AS);
% utilise les champs .pretinent, .R et .reprodR
% pour calculer le 'fit' de la solution
% qu'il faudra apprécier en différence avec une référence et en degrés de
% liberté
% AS.pertinent=1:AS.nv;  % temporairement ???
br=AS.branche;
br2=AS.branche2;
br3=AS.branche3;
nv=numel(AS.P(br).pertinent);
R=AS.R(AS.P(br).pertinent,AS.P(br).pertinent);
S=AS.P(br).G(br2).C(br3).reprodR(AS.P(br).pertinent,AS.P(br).pertinent);
S=S+diag(1-diag(S));
X2=(AS.N-1)*(log(det(S))-log(det(R))+trace(R/S)-nv);
if numel(AS.P(br).G(br2).Gr)==1 
    co=0;
else
    co=triU(AS.P(br).G(br2).C(br3).CorFct);
end
df=nv*(nv+1)/2-nv-sum(AS.P(br).G(br2).Fct(:)~=0)-sum(co~=0);
p=1-chi2cdf(X2,df);