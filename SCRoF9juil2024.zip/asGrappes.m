function AS=asGrappes(AS)
% AS=grappes(AS);
% Calcule les distances (en X2)
% Effectue les regroupements(linkage)
% Établit le seuil de coupure en terme de probabilité (prob d'erreur
% de type I) du lien plutôt que celle du pire
% Détermine quels liens sont dans la fourchette .01 à .20 et crée des
% branches en fonction de cela 
AS=asDistances(AS);
br=AS.branche;
Z=linkage(AS.P(br).Dist,'complete');
% AS.P(br).Z=Z;
p=1-AS.seuils;
nv=numel(AS.P(br).pertinent);
Gr{nv}=[];
for k=1:nv
    Gr{k}=AS.P(br).pertinent(k);
end
nZ=size(Z,1);
pr=zeros(nZ,1);
nz=0;
for k=1:nZ
    a=Gr{Z(k,1)};
    b=Gr{Z(k,2)};
    nx=numel(a)*numel(b);
    nz=nz+1;
    pr(k,:)=1-chi2cdf(Z(k,3),nv-2).^nx;  %probabilité ajustée
    % crit(k,:)=chi2inv(chi2cdf(Z(k,3),nv-2).^nx,1);
    Gr{end+1}=sort([a b]);
end
AS.P(br).Z=Z;
AS.P(br).pr=pr;
f=find(pr>AS.seuils(1),1,'last');
if isempty(f)
    f=nv-1;
end
[AS.P(br).G(1).Gr,AS.P(br).G(1).reste]=asNettoie(Gr(1:(nv+f))); % réunir
AS.P(br).G(1).coupure=AS.seuils(1);
f=find((pr>AS.seuils(1) & pr<AS.seuils(2))); 
if numel(f)>1
    g=find(f(2:end)==f(1:end-1));  % relation hiérarchique, premier comme 2e
    if ~isempty(g)
        f(g)=[];
    end
end
if ~isempty(f)
    if numel(f)==1
        c{1}=f;
    else
        c=subsets(f);
    end
    for j=1:numel(c)
        [AS.P(br).G(end+1).Gr,AS.P(br).G(end+1).reste]=asNettoie(Gr(1:(nv-1+c{j})));
        AS.P(br).G(end).coupure=AS.seuils(2);
    end
end
for k=1:numel(AS.P(br).G) 
    AS.branche2=k;
    AS=asCoplanaire(AS);
end
% 
% 
% % if ~isempty(f)
% 
%     % crit(nz,:)=chi2inv(p.^(1/nx),nv-2);  % vaut 0 si nx==0
%     % if AS.Z(br)(k,3)<crit(1)  % si pas significatif pour seuil 1, unir les groupes
%     % Gr{AS.Z(br)(k,1)}=[];
%     % Gr{AS.Z(br)(k,2)}=[];
%     %     AS.X2crit(br)=crit;   % garder le dernier critère satisfait
%     % else
%     %     Gr{end+1}=[];
%     % end
% % end
% AS.P(br).crit=crit;
% % nb=[];
% m=numel(Gr);
% AS.P(br).G(1).Gr=Gr;
% br2=1;
% % AS.branche=[AS.branche 1];
% for k=nZ:-1:1
%     if AS.P(br).Z(k,3)>crit(k,1)   % ne pas accepter ce regroupement
%         AS.P(br).G(br2).Gr{m}=[];
%     elseif AS.P(br).Z(k,3)>=crit(k,2) % ne pas accepter et accepter ce regroupement
%         br2=br2+1;
%         AS.P(br).G(br2).Gr=AS.P(br).G(br2-1).Gr;
%         AS.P(br).G(br2-1).Gr{m}=[];
%         AS.P(br).G(br2).Gr=asNettoie(AS.P(br).G(br2).Gr);
%     else  %if AS.P(br).Z(k,3)>crit(k,1)
%         AS.P(br).G(br2-1).Gr=asNettoie(AS.P(br).G(br2-1).Gr);
%         break
%     end
%     m=m-1;
% end
% for k=1:numel(AS.P(br).G)
%     AS.P(br).G(k).reste=[];
%     nb=[];
%     n=numel(AS.P(br).G(k).Gr);
%     if n<2
%         AS.P(br).G(k).reste=[AS.P(br).G(k).Gr AS.P(br).G(k).reste];
%     else
%         nb=[n nb];
%     end
%     [~,oo]=sort(nb,'descend');
%     AS.P(br).G(k).Gr=AS.P(br).G(k).Gr(oo);
% end
% end

