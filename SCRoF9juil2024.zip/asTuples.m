function AS=asTuples(AS,k)
% AS=asTuples(AS,k);
% AS.GS(v,v) est la GrammSchmidt (en triangle supérieur) de R(v,v)
% Si k est un scalaire, optimise les variables de la rangée k de AS.P(br).Cpaire pour en minimiser le signal
% Autrement, optimise les valeurs de k(1:end-1) pour minimiser le signal dans k(end)
% Le champ AS.tmp retourne alors le critère, les corrélations avec les
% autres variables et les poids optimisés

% ajoute AS.Crit
% Po, si présent, contient les poids optimaux des numel(melange) variables
% corr(1,v) contient les corrélations du contraste optimisé avec chacune des autres variables
br=AS.branche;
if ~isfield(AS.P(br),'pertinent')
    AS.P(br).pertinent=1:AS.nv;
end
cible=AS.P(br).pertinent;
if numel(k)==1
    melange=AS.P(br).Cpaires(k,:);
else
    melange=k;
end
mul=[.5 1 2 4];
nm=numel(mul);
cr=zeros(nm,1);
cor=zeros(AS.nv,nm);
Po=zeros(numel(melange)-1,nm);
P=AS.GS(:,melange(1:end-1))'*AS.GS(:,melange(end));  % initialiser aux corrélations avec cible
for e=1:nm 
    Po(:,e)=NM_AA(mul(e)*P,AS.GS,melange,cible); % relance l'optimisation à partir de la solution antérieure
    [cr(e),cor(:,e)]=asCrit(Po(:,e),AS.GS,melange,cible);
    cr(e)=cor(:,e)'*cor(:,e); % bien qu'on ait minimisé la valeur absolue maximale des corrélations
end
f=find(cr==min(cr),1);   
if numel(k)==1
    AS.P(br).Crit(k)=cr(f); 
    AS.P(br).Corr(:,k)=cor(:,f);
    AS.P(br).Ppaires(k,:)=Po(:,f)';
else
    AS.tmp.Crit=cr(f);
    AS.tmp.Corr=cor(:,f);
    AS.tmp.Poids=Po(:,f);
end
end