function AS=asVariablesRestantes(AS)
% AS=asVariablesRestantes(AS);
% Utilise divers champs de AS
% Essaie d'abord toutes les combinaisons des variables dans AS.reste entre
% elles pour essayer d'en annuler le signal
% Si nécessaire, ajoute à ces cominaisons de variables restantes des
% variables représentatives des facteurs déjà cernés
% Cela fait ajouter des directions à titre de facteur qui n'ont toutefois
% pas l'invariabilité d'orientation de ceux cernés par une paire (au moins)
% d'indicatrices unifactorielles.
% la fonction peut être appelée récursivement
nf=numel(AS.Gr);
if ~isfield(AS,'avantReste')   % s'assurer de le faire qu'une fois
    AS.avantReste=nf; % garder l'information sur les directions fiables
end
if isempty(AS.reste)
    return
end
nr=numel(AS.reste);
if nr<2
    warning('Anomalie! Il ne devrait pas rester UNE SEULE variable à expliquer par de nouveaux facteurs.');
    return
end
if nr>2
    % première passe, seulement des variables encore inexpliquées
    Ss=subsets(AS.reste,3,nr);
    ns=numel(Ss);
    for k=1:ns
        % [p,X2,Corr,Poids]=as_tuple(AS,Ss{k});
        p=as_tuple(AS,Ss{k});
        if p>.05
            % le signal semble s'annuler
            R=AS.GS(:,Ss{k})'*AS.GS(:,Ss{k});
            s=sum(R);
            f=find(s==max(s),1); % le rang de la variable jugée multifactorielle parmi Ss{k}
            nouvFct=setdiff(Ss{k},Ss{k}(f));
            for j=nouvFct(:)'
                AS.Gr{end+1}=j;
                AS.Var(end+1)=j;
                AS.GrDe(j)=numel(AS.Gr);
                AS.reste(AS.reste==j)=[];
            end
            if isempty(AS.reste)
                return
            else
                AS=asVariablesMulti(AS);
                AS=asVariablesRestantes(AS);
                return
            end
        end
    end
end
% deuxième passe, si requis, inexpliques avec représentantes des facteurs cernés par une paire
nr=numel(AS.reste);
Ss=subsets(AS.reste,2,nr);
ns=numel(Ss);
deja=subsets(AS.Var(1:AS.avantReste));
nd=numel(deja);
for k=1:ns
    for j=1:nd
        p=as_tuple(AS,[deja{j} Ss{k}]);
        if p>.05
            % le signal semble s'annuler
            keyboard
        end
    end
end
end



