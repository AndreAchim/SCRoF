function AS=asCoplanaire(AS)
% AS=asCoplanaire(AS);
% si trois groupes n'occupent qu'un plan, en enlever un
% Mais comment faire avant d'avoir estimé les saturations?
% En estimant ces saturations (sans moyenner sur toutes les paires du groupe)
br=AS.branche;
br2=AS.branche2;
if ~isfield(AS,'branche3'), AS.branche3=1; end
br3=AS.branche3;
coplan=[];
GrCoplan=[];
AS.P(br).G(br2).coplan=coplan;
AS.P(br).G(br2).GrCoplan=GrCoplan;
ote=[];
Gr=AS.P(br).G(br2).Gr;
ng=numel(Gr);
if ng<3
    AS.P(br).G(br2).Fct=zeros(AS.nv,ng);
    AS=asSaturations(AS);   % prépare aussi AS.Var: une variable par groupe et AS.GrDe
    AS=asVariablesMulti(AS);
    if numel(AS.P(br).G(br2).Gr)>1
        AS=asCorrFct(AS);
    else
        AS.P(br).G(br2).C(br3).CorFct=1;
    end
    AS.P(br).G(br2).C.reprodR=AS.P(br).G(br2).Fct*AS.P(br).G(br2).C(br3).CorFct*AS.P(br).G(br2).Fct';
    [p,X2,df]=asFit(AS);
    AS.P(br).G(br2).C.Fit=[p,X2,df];
    return
end
options=optimset('MaxFunEvals',1e4,'MaxIter',1e4,'TolFun',1e-6,'TolX',1e-6);
trios=nchoosek(1:ng,3);
cible=1:numel(AS.P(br).pertinent);
for tri=trios'  % pour chaque trio de groupes
    nt=0;
    pire=0;
    for i=Gr{tri(1)}
        for j=Gr{tri(2)}
            for k=Gr{tri(3)}
                nt=nt+1;
                melange=[i j k];
                if any(melange<0) % ignorer un groupe déjà à exclure
                    pire=-1;
                else
                    % si les deux plus grandes corrélations ne sont pas essentiellement égales,
                    % essayer avec nouvelles initialisations
                    mul=[1 .5 2];
                    for e=1:numel(mul)
                        P=sign(AS.GS(:,melange(1:end-1))'*AS.GS(:,melange(end)));  % initialiser à +ou - 1 selon signe de corrélations
                        P=mul(e)*P./sqrt(numel(P));
                        P=fminsearch(@(P) asCrit(P,AS.GS,melange,cible),P,options);
                        [~,cor]=asCrit(P,AS.GS,melange,cible);
                        cor=cor';
                        cr=cor'*cor;
                        c=sort(abs(cor));
                        if c(end)-c(end-1)<.0001 && all(abs(log10(P))<2)
                            break;
                        end
                    end
                    if c(end)-c(end-1)>.0001
                        keyboard  % l'optimisation n'a pas trouvé un vrai creux
                    end
                    if cr>pire
                        pire=cr;
                    end
                end
            end
        end
    end
    if pire>0
        pire=pire*(AS.N-1);        % pire est le plus grand de nt X2(nv-3)
        pr=chi2cdf(pire,numel(cible)-3);  % devient 1-p
        Lpr=-log10(1-pr.^nt);       % puis -log10 de p corrigé
        if Lpr<AS.Lseuils(1)  % autrement, nettement pas coplanaire; laisser comme c'est
            % On voudra plutôt ajouter à AS.P(br).G les trois scénarios du groupe coplanaire <<<<<<
            if Lpr>AS.Lseuils(2) % laisser comme c'est et ajouter un traitement coplanaire
                AS.P(br).G(end+1).Gr=Gr;  % Laisser une copie comme si le X2 était significatif (pas coplanaire)
                AS.P(br).G(end).coupure=AS.seuils(2);
            end
            % les groupes dans tri sont considérés coplanaires
            % caculer les saturations à partir des deux premières variables de groupe
            s=zeros(3,2);
            v=zeros(3,2);
            for g=1:3
                v(g,:)=Gr{tri(g)}(1:2);  % les deux premières variabes de chaque groupe
                s(g,:)=asSatPaire(AS,v(g,:));  % leurs saturations
            end
            C=zeros(3,3);
            for g1=1:2
                for g2=(g1+1):3  % pour les trois paires degroupes
                    co=0;
                    for j=1:2 % pour les deux variables du premier groupe
                        for k=1:2  % deux variables du deuxième groupe corrélées à celles du prem
                            co=co+AS.GS(:,v(g1,j))'*AS.GS(:,v(g2,k))/(s(g1,j)*s(g2,k));
                        end
                    end
                    C(g1,g2)=abs(co)/4;
                end
            end
            C=triU(C);
            mi=min(C); % corrélation de la paire la plus orthogonale
            % les positions dans C sont 12, 13 et 23, les rangs manquant sont 3, 2 et 1 d'où:
            f=4-find(C==mi,1);
            f=tri(f);
            ote=[ote f];
            AS.P(br).G(br2).GrCoplan{end+1}=Gr{f};
            AS.P(br).G(br2).Gr{f}=-AS.P(br).G(br2).Gr{f};
            % en garder trace dans AS.coplan
            % AS.P(br).G(br2).
            AS.P(br).G(br2).coplan=[coplan;tri'];
        end
    end
end
for k=1:numel(ote)
    AS.P(br).G(br2).reste=[AS.P(br).G(br2).reste -AS.P(br).G(br2).Gr{ote(k)}];
end
AS.P(br).G(br2).Gr(ote)=[];   %%%%
% nv=AS.nv;  % plutôt que numel(cible) pour garder les orphelines
for br2=1:numel(AS.P(br).G)
    AS.branche2=br2;
    ng=numel(AS.P(br).G(br2).Gr);
    AS.P(br).G(br2).Fct=zeros(AS.nv,ng);
    % Estimer saturations des facteurs pour les variables unifactorielles
    AS=asSaturations(AS);   % prépare aussi AS.Var: une variable par groupe et AS.GrDe
    AS=asVariablesMulti(AS); % idem pour variables multifactorielles
    AS=asCorrFct(AS);  % estimer les corrélations entre facteurs
    % AS=asVariablesMulti(AS);
    for k=1:numel(AS.P(br).G(br2).C)
        AS.branche3=k;
        try
        AS.P(br).G(br2).C(k).reprodR=AS.P(br).G(br2).Fct*AS.P(br).G(br2).C(k).CorFct*AS.P(br).G(br2).Fct';
        [p,X2,df]=asFit(AS);
        catch
            keyboard
        end
        AS.P(br).G(br2).C(k).Fit=[p,X2,df];
    end
    % % Annuler les variables restantes à partir des groupes identifiés
end
