function dendr(AS,rang)
% dendr(AS,rang);
% rang (défaut 1) est le rang du scénario (par ordre de mérite)
% produit le dendrogramme des regroupements à partir de paires dans SCRoF
figure
if nargin<2
    rang=1;
end
br=AS.scenario(rang,4:end);
Z=AS.P(br(1)).Z;
nv=numel(AS.P(br(1)).pertinent);
ng=find(AS.P(br(1)).pr<=AS.P(br(1)).G(br(2)).coupure,1,"first");
if isempty(ng)
    crit=Z(end,3)+1;   % un seul groupe
else
    crit=mean(Z(ng-1:ng,3));
end
Z(:,3)=sqrt(Z(:,3));
crit=sqrt(crit);
AxeY='sqrt(X^2)';
dendrogram(Z,'ColorThreshold',crit);
lb=xticklabels;
v=str2num(lb);
if ~isempty(AS.P(br(1)).G(br(2)).GrCoplan)
    for j=1:numel(AS.P(br(1)).G(br(2)).GrCoplan)
        cop=AS.P(br(1)).G(br(2)).GrCoplan{j};
        for k=1:numel(cop)
            v(v==cop(k))=-v(v==cop(k));
        end
    end
end
noms{nv}='';
for k=1:size(v)
    noms{k}=num2str(v(k));
end
xticklabels(noms);
hold on
% plot([0 numel(v)+1],crit*[1 1],'--k');
ylabel(AxeY);
fit=AS.scenario(rang,1:3);
titre=sprintf('N=%d   X^2(%d)=%.2f p=%.3f (pre-ML)',AS.N,fit([3,2,1]));
if isfield(AS,'titre')
    titre=[AS.titre '  ' titre];
end
title(titre);
% mi=AS.P(br(1)).Z(end,3);
% crit=sort(unique([crit,-log10([.1 .01 .001 .0001])]));
% while ~isempty(crit) && crit(end)>mi, crit(end)=[]; end
% if ~isempty(crit)
%     p=10.^-crit;
%     p=round(p,1,'significant');
%     plb{numel(p)}='';
%     for k=1:numel(p)
%         plb{k}=sprintf('%f',p(k));
%         while(plb{k}(end)=='0'),plb{k}(end)=[];end
%         if p(k)<=.001
%             plb{k}=['<',plb{k}];
%         end
%     end
%     % yl=ylim;
%     % yyaxis right
%     % yyaxis left
%     % ylim(yl);
%     yticks(crit);
%     yticklabels(plb)
% end