function ote=asAutresOrphelines(AS)
% ote=asAutresOrphelines(AS);
% utilise les poids Ppaires de la présente branche pour détecter une
% éventuelle variable qui aurait un poids incompatible en signe avec la
% corrélation correspondante. 
% ote contient la liste des variables ainsi détectées comme orphelines
% La gestion (abandon) de la branche est faite dans la fonctio qui appelle celle-ci 

% Si cela arrive, la variable est ajoutée à la
% liste des variables. Si cela créerait une branche identique à une autre déjà
% là, la branche n'est pas ajoutée. Autrement, les champs AS.GS et 
% AS.P(br).pertinent) sont mis à jour. pour la branche de premier niveau
% ajoutée.
br=AS.branche;
v=AS.P(br).pertinent;
nv=numel(v);
ote=[];
for j=1:nv-1
    for k=j+1:nv
        r=AS.R(v(j),v(k));
        pa=find(ismember(AS.P(br).Cpaires,[v(j),v(k)],'rows'));
        p=AS.P(br).Ppaires(pa);
        if r*p<0   % j ou k est orpheline si signe(poids)~=signe(corr.observée)
            rj=AS.R(v(j),:)*AS.R(:,v(j));
            rk=AS.R(v(k),:)*AS.R(:,v(k));
            if rj<rk
                ote=[ote,v(j)];
            else
                ote=[ote,v(k)];
            end
        end
    end
end
% keyboard
% if isempty(ote)
%     return
% end
ote=unique(ote);
