function AS=asVariablesMulti(AS)
% AS=asVariablesMulti(AS);
% Utiise une variable de chaque groupe (facteur) pour expliquer (par
% annulation du signal) les variables dans AS.reste
br=AS.branche;
br2=AS.branche2;
ng=numel(AS.P(br).G(br2).Gr);
if ng<2
    return
end
for np=2:ng   % nombre de prédicteurs
    if isempty(AS.P(br).G(br2).reste)
        break
    else
        while ~isempty(AS.P(br).G(br2).reste) && max(AS.P(br).G(br2).reste)>0
            AS=asMultiSatur(AS,np);
            while ~isempty(AS.P(br).G(br2).reste) && AS.P(br).G(br2).reste(1)<0 && any(AS.P(br).G(br2).reste>0)
                AS.P(br).G(br2).reste=[AS.P(br).G(br2).reste(2:end) AS.P(br).G(br2).reste(1)];
            end
        end
    end
    AS.P(br).G(br2).reste=abs(AS.P(br).G(br2).reste); % remettre en positifs les variables pas résolues avec le np courant
end
