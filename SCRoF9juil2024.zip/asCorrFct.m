function AS=asCorrFct(AS)
% AS=asCorrFct(AS);
% estime les corrélations entre les variables des facteurs
% ramène à 0 celles qui ne sont pas significatives
% et corrige les corrélations des variables pour devenir celles des facteurs
br=AS.branche;
br2=AS.branche2;
AS.P(br).G(br2).CorEstim=[];
ng=numel(AS.P(br).G(br2).Gr);
corr=zeros(ng);
coBr=zeros(ng);
for j=1:ng-1
    varJ=AS.P(br).G(br2).Gr{j};
    nj=numel(varJ);
    for k=(j+1):ng
        varK=AS.P(br).G(br2).Gr{k};
        nk=numel(varK);
        corrBrut=zeros(nj*nk,1);  % corr des variables (pour test := 0)
        corrCorrige=zeros(nj*nk,1); % corr des facteurs (pour moyenner)
        rg=0;
        for j1=1:nj
            for k1=1:nk
                rg=rg+1;
                corrBrut(rg)=AS.GS(:,varJ(j1))'*AS.GS(:,varK(k1));
                corrCorrige(rg)=corrBrut(rg)/(AS.P(br).G(br2).Fct(varJ(j1),j)*AS.P(br).G(br2).Fct(varK(k1),k));
            end
        end
        corr(j,k)=mean(corrCorrige);
        coBr(j,k)=mean(corrBrut);
        AS.P(br).G(br2).CorEstim{end+1}=corrCorrige(:);
    end
end
% maintenant annuler les corrélations non significatives
% et corriger les autres corrélation de celles des variabes à celles des facteurs
limCorr=-norminv(.5*AS.seuils)./sqrt(AS.N-1);  % ne tient pas compte qu'on a moyenné des corrélations
[coBr,rg]=triU(abs(coBr));
f=find(coBr<limCorr(2));
if ~isempty(f)
    for k=f'
        corr(rg(k,1),rg(k,2))=0;
    end
end
AS.P(br).G(br2).C(1).CorFct=corr+corr'+eye(ng); % garder toutes les corrélations à p>AS.seuils(2)
CORR=corr;
f=find(coBr>limCorr(2) & coBr<limCorr(1));
if ~isempty(f)
    if numel(f)==1
        ss{1}=f;
    else
        ss=subsets(f);
    end
    for k=1:numel(ss)   % liste de corrélations à annuler dans des branches distinctes
        corr=CORR;
        for j=ss{k}
            corr(rg(j,1),rg(j,2))=0;
        end
        AS.P(br).G(br2).C(end+1).CorFct=corr+corr'+eye(ng);
    end
end