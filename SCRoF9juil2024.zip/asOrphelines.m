function AS=asOrphelines(AS)
% AS=asOrphelines(AS);
% utilise AS.R pour identifier ses colonnes dont la plus grande valeur
% absolue (excluant la diagonale) n'est pas significative (p>.05)
% il faudrait voir si la régression multiple de chaque variabe sur toutes
% les autres pourrait être plus fiable
R=AS.R-eye(AS.nv);
z2=max(abs(R)).^2*(AS.N-1);
f=find(z2<chi2inv((1-AS.seuils(2))^(1/(AS.nv-1)),1));  % à exclure et peut-être à garderdans des scénarios distincts
g=find(z2<chi2inv((1-AS.seuils(1))^(1/(AS.nv-1)),1));  % à exclure sûrement
y=setdiff(g,f);
% AS.branche=1;
AS.P(1).orphelines=f;
if ~isempty(y)
    if numel(y)==1
        c{1}=y;
    else
        c=subsets(y);
    end
    for j=1:numel(c)
        AS.P(j+1).orphelines=[f c{j}];
    end
end
% if ~isempty(f)
%     AS.GS(:,f)=0; % pour rendre toutes les corrélations nulles sans mélanger les rangs des variables
% end
% AS.pertinent=setdiff(1:AS.nv,AS.orphelines);